import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { Observable } from 'rxjs';

const baseUrl = 'http://localhost:6868/api/telemetrys/';

@Component({
  selector: 'app-history',
  standalone: true,
  imports: [HttpClientModule],
  templateUrl: './history.component.html',
  styleUrl: './history.component.scss'
})
export class HistoryComponent {

  telemetrys?: any[];
  currentTelemetry: any = {};
  currentIndex = -1;
  title = '';

  constructor(private http: HttpClient) { }
  
  ngOnInit(): void {
    this.retrieveTelemetrys();
  }

  retrieveTelemetrys(): void {
    this.getAll()
      .subscribe({
        next: (data) => {
          this.telemetrys = data;
          console.log(data);
        },
        error: (e) => console.error(e)
      });
  }

  getAll(): Observable<any[]> {
    return this.http.get<any[]>(baseUrl);
    
  }

}
